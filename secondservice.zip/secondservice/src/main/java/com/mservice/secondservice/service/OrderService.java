package com.mservice.secondservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mservice.secondservice.dto.ProdcutDTO;
import com.mservice.secondservice.feignclient.Productclient;

@Service
public class OrderService {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private Productclient productclient;

	public List<ProdcutDTO> fetchproducts() {

		// ResponseEntity<ProdcutDTO[]> response =
		// restTemplate.getForEntity(PRODUCT_SERVICE_URL, ProdcutDTO[].class);
//	ProdcutDTO[] products = response.getBody();
//	return Arrays.asList(products);

//		ResponseEntity<List<ProdcutDTO>> response = restTemplate.exchange("http://firstservice/products/getAllProducts",
//				HttpMethod.GET, null, new ParameterizedTypeReference<List<ProdcutDTO>>() {
//				});
//
//		return response.getBody();

		 return productclient.getAllProducts();

	}

	public ProdcutDTO createProduct(ProdcutDTO product) {

//		ResponseEntity<ProdcutDTO> response = restTemplate.postForEntity("http://firstservice/products/addProduct",
//				product, ProdcutDTO.class);
//		return response.getBody();
		return productclient.addProduct(product);
	}
}
