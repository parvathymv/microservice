package com.mservice.secondservice.feignclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


import com.mservice.secondservice.dto.ProdcutDTO;

@FeignClient(name = "firstservice")
public interface Productclient {
	
	 @GetMapping("/products/getAllProducts")
	    public List<ProdcutDTO> getAllProducts() ;
	 
	 @PostMapping("/products/addProduct")
	    public ProdcutDTO addProduct(@RequestBody ProdcutDTO product);

}
