package com.mservice.secondservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mservice.secondservice.dto.ProdcutDTO;
import com.mservice.secondservice.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {

	@Autowired
	private OrderService orderService;



	@GetMapping("/fetch-products")

	public List<ProdcutDTO> fetchProducts() {
		return orderService.fetchproducts();

	}

	@PostMapping("/createProduct")
	public ProdcutDTO createProduct(@RequestBody ProdcutDTO product) {
     return orderService.createProduct(product);
	}

}
