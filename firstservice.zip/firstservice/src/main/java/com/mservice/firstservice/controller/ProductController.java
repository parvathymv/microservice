package com.mservice.firstservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mservice.firstservice.dto.ProductDTO;
import com.mservice.firstservice.entity.Product;
import com.mservice.firstservice.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
   ProductService productService;
	@Autowired
    Environment environment;
	
    @GetMapping("/getAllProducts")
    public List<ProductDTO> getAllProducts() {
       return productService.getAllProducts();
       // return "data of product-SERVICE, Running on port: " +environment.getProperty("local.server.port");
    }

    @PostMapping("/addProduct")
    public ProductDTO addProduct(@RequestBody ProductDTO product) {
        return productService.addProduct(product);
    }
}
