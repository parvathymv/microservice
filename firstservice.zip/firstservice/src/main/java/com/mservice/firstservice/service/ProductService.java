package com.mservice.firstservice.service;

public class ProductService {

}
