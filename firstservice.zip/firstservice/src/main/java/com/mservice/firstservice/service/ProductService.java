package com.mservice.firstservice.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mservice.firstservice.dto.ProductDTO;
import com.mservice.firstservice.entity.Product;
import com.mservice.firstservice.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ModelMapper modelMapper;

	public List<ProductDTO> getAllProducts() {

		 List<Product> list=productRepository.findAll();
	        List<ProductDTO> plist=list.stream().map(product->modelMapper.map(product, ProductDTO.class)).
	        		collect(Collectors.toList());
	        return plist;
	}

	public ProductDTO addProduct(ProductDTO productDTO) {
		Product savedProduct=productRepository.save(modelMapper.map(productDTO, Product.class));
        return modelMapper.map(savedProduct, ProductDTO.class);
	}

}
